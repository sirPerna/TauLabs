EEG.GBL - bottom copper
EEG.GBS - bottom soldermask
EEG.GM1 - mechanical cutout
EEG.GTL - top copper
EEG.GTO - top overlay
EEG.GTP - stencil
EEG.GTS - top slodermask
EEG.TXT - drill map
